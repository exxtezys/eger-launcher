## About

This is the repository for FancyMenu, a mod for Minecraft to customize menus.

## Branches | Source Code

Check the branches to see the **source code** for all versions of FancyMenu.

## Copyright

FancyMenu © Copyright 2020-2026 Keksuccino.<br>
FancyMenu is licensed under DSMSLv3.1 (DON'T SNATCH MA STUFF LICENSE V3.1).<br>
See `LICENSE.md` for more information.

Japng © Copyright A. Ellerton.<br>
Japng is licensed under Apache-2.0.

[Animated GIF library for Java](https://github.com/rtyley/animated-gif-lib-for-java) © Copyright Roberto Tyley, Kevin Weiner.<br>
Original code by Kevin Weiner on [fmsware.com](http://www.fmsware.com/stuff/gif.html).<br>
Re-packaged and improved by Roberto Tyley. Improvements licensed under the Apache-2.0 license.
